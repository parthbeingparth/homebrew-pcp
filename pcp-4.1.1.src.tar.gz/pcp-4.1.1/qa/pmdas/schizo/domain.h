#define SCHIZO 241
