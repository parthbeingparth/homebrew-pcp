#include <stdio.h>


main(int argc, char *argv[]) {
    printf("This program does nothing, and wastes a lot of space doing it!\n");
    exit(0);
}
