/*
 * indom - exercise pmGetInDom, pmNameInDom and pmLookupInDom
 */

#include <pcp/pmapi.h>

static int	type;
static int	inst;

int
dometric(char *name)
{
    pmID	pmid;
    pmDesc	desc;
    int		sts;
    char	*iname;
    int		*ilist;
    char	**nlist;

    if ((sts = pmLookupName(1, &name, &pmid)) < 0)
	return sts;

    if ((sts = pmLookupDesc(pmid, &desc)) < 0)
	return sts;

    iname = "no match";
    printf("pm*InDom: inst=[%d]", inst);
    if ((sts = pmNameInDom(desc.indom, inst, &iname)) < 0)
	printf(" {%s}\n", pmErrStr(sts));
    else {
	printf(" iname=<%s> reverse lookup:", iname);
	if ((sts = pmLookupInDom(desc.indom, iname)) < 0)
	    printf(" {%s}\n", pmErrStr(sts));
	else
	    printf(" inst=[%d]\n", sts);
    }
    if (type == PM_CONTEXT_ARCHIVE) {
	iname = "no match";
	printf("pm*InDomArchive: inst=[%d]", inst);
	if ((sts = pmNameInDomArchive(desc.indom, inst, &iname)) < 0)
	    printf(" {%s}\n", pmErrStr(sts));
	else {
	    printf(" iname=<%s> reverse lookup:", iname);
	    if ((sts = pmLookupInDomArchive(desc.indom, iname)) < 0)
		printf(" {%s}\n", pmErrStr(sts));
	    else
		printf(" inst=[%d]\n", sts);
	}
    }

    if ((sts = pmGetInDom(desc.indom, &ilist, &nlist)) < 0)
	printf("pmGetInDom: {%s}\n", pmErrStr(sts));
    else {
	int		i;
	printf("pmGetInDom:\n");
	for (i = 0; i < sts; i++) {
	    if (ilist[i] == inst) {
		printf("   [%d] <%s>\n", ilist[i], nlist[i]);
		break;
	    }
	}
	free(ilist);
	free(nlist);
    }

    if (type == PM_CONTEXT_ARCHIVE) {
	if ((sts = pmGetInDomArchive(desc.indom, &ilist, &nlist)) < 0)
	    printf("pmGetInDomArchive: {%s}\n", pmErrStr(sts));
	else {
	    int		i;
	    printf("pmGetInDomArchive:\n");
	    for (i = 0; i < sts; i++) {
		if (i == inst) {
		    printf("   [%d] <%s>\n", ilist[i], nlist[i]);
		    break;
		}
	    }
	    free(ilist);
	    free(nlist);
	}
    }

    return sts;
}

int
main(int argc, char **argv)
{
    int		c;
    int		sts;
    int		errflag = 0;
    int		force = 0;
    int 	verbose = 0;
    char	*host = NULL;			/* pander to gcc */
    char 	*configfile = (char *)0;
    char 	*logfile = (char *)0;
    pmLogLabel	label;				/* get hostname for archives */
    int		zflag = 0;			/* for -z */
    char 	*tz = (char *)0;		/* for -Z timezone */
    int		tzh;				/* initial timezone handle */
    char	local[MAXHOSTNAMELEN];
    char	*namespace = PM_NS_DEFAULT;
    int		samples = -1;
    double	delta = 1.0;
    char	*endnum;

    pmSetProgname(argv[0]);

    while ((c = getopt(argc, argv, "a:c:D:fh:i:l:n:s:t:VzZ:?")) != EOF) {
	switch (c) {

	case 'a':	/* archive name */
	    if (type != 0) {
		fprintf(stderr, "%s: at most one of -a and/or -h allowed\n", pmGetProgname());
		errflag++;
	    }
	    type = PM_CONTEXT_ARCHIVE;
	    host = optarg;
	    break;

	case 'c':	/* configfile */
	    if (configfile != (char *)0) {
		fprintf(stderr, "%s: at most one -c option allowed\n", pmGetProgname());
		errflag++;
	    }
	    configfile = optarg;
	    break;	


	case 'D':	/* debug options */
	    sts = pmSetDebug(optarg);
	    if (sts < 0) {
		fprintf(stderr, "%s: unrecognized debug options specification (%s)\n",
		    pmGetProgname(), optarg);
		errflag++;
	    }
	    break;

	case 'f':	/* force */
	    force++; 
	    break;	

	case 'h':	/* contact PMCD on this hostname */
	    if (type != 0) {
		fprintf(stderr, "%s: at most one of -a and/or -h allowed\n", pmGetProgname());
		errflag++;
	    }
	    host = optarg;
	    type = PM_CONTEXT_HOST;
	    break;

	case 'i':	/* instance */
	    inst = (int)strtol(optarg, &endnum, 10);
	    if (*endnum != '\0' || inst < 0) {
		fprintf(stderr, "%s: -i requires numeric argument\n", pmGetProgname());
		errflag++;
	    }
	    break;

	case 'l':	/* logfile */
	    logfile = optarg;
	    break;

	case 'n':	/* alternative name space file */
	    namespace = optarg;
	    break;

	case 's':	/* sample count */
	    samples = (int)strtol(optarg, &endnum, 10);
	    if (*endnum != '\0' || samples < 0) {
		fprintf(stderr, "%s: -s requires numeric argument\n", pmGetProgname());
		errflag++;
	    }
	    break;

	case 't':	/* delta seconds (double) */
	    delta = strtod(optarg, &endnum);
	    if (*endnum != '\0' || delta <= 0.0) {
		fprintf(stderr, "%s: -t requires floating point argument\n", pmGetProgname());
		errflag++;
	    }
	    break;

	case 'V':	/* verbose */
	    verbose++;
	    break;

	case 'z':	/* timezone from host */
	    if (tz != (char *)0) {
		fprintf(stderr, "%s: at most one of -Z and/or -z allowed\n", pmGetProgname());
		errflag++;
	    }
	    zflag++;
	    break;

	case 'Z':	/* $TZ timezone */
	    if (zflag) {
		fprintf(stderr, "%s: at most one of -Z and/or -z allowed\n", pmGetProgname());
		errflag++;
	    }
	    tz = optarg;
	    break;

	case '?':
	default:
	    errflag++;
	    break;
	}
    }

    if (zflag && type == 0) {
	fprintf(stderr, "%s: -z requires an explicit -a or -h option\n", pmGetProgname());
	errflag++;
    }

    if (errflag) {
	fprintf(stderr,
"Usage: %s options ...\n\
\n\
Options\n\
  -a   archive	  metrics source is an archive log\n\
  -c   configfile file to load configuration from\n\
  -D   debugspec  standard PCP debugging options\n\
  -f		  force .. \n\
  -h   host	  metrics source is PMCD on host\n\
  -l   logfile	  redirect diagnostics and trace output\n\
  -n   namespace  use an alternative PMNS\n\
  -s   samples	  terminate after this many iterations\n\
  -t   delta	  sample interval in seconds(float) [default 1.0]\n\
  -V 	          verbose/diagnostic output\n\
  -z              set reporting timezone to local time for host from -a or -h\n\
  -Z   timezone   set reporting timezone\n",
		pmGetProgname());
	exit(1);
    }

    if (logfile != (char *)0) {
	pmOpenLog(pmGetProgname(), logfile, stderr, &sts);
	if (sts < 0) {
	    fprintf(stderr, "%s: Could not open logfile \"%s\"\n", pmGetProgname(), logfile);
	}
    }

    if (namespace != PM_NS_DEFAULT) {
	if ((sts = pmLoadASCIINameSpace(namespace, 1)) < 0) {
	    fprintf(stderr, "%s: Cannot load namespace from \"%s\": %s\n", pmGetProgname(), namespace, pmErrStr(sts));
	    exit(1);
	}
    }

    if (type == 0) {
	type = PM_CONTEXT_HOST;
	gethostname(local, sizeof(local));
	host = local;
    }
    if ((sts = pmNewContext(type, host)) < 0) {
	if (type == PM_CONTEXT_HOST)
	    fprintf(stderr, "%s: Cannot connect to PMCD on host \"%s\": %s\n",
		pmGetProgname(), host, pmErrStr(sts));
	else
	    fprintf(stderr, "%s: Cannot open archive \"%s\": %s\n",
		pmGetProgname(), host, pmErrStr(sts));
	exit(1);
    }

    if (type == PM_CONTEXT_ARCHIVE) {
	if ((sts = pmGetArchiveLabel(&label)) < 0) {
	    fprintf(stderr, "%s: Cannot get archive label record: %s\n",
		pmGetProgname(), pmErrStr(sts));
	    exit(1);
	}
    }

    if (zflag) {
	if ((tzh = pmNewContextZone()) < 0) {
	    fprintf(stderr, "%s: Cannot set context timezone: %s\n",
		pmGetProgname(), pmErrStr(tzh));
	    exit(1);
	}
	if (type == PM_CONTEXT_ARCHIVE)
	    printf("Note: timezone set to local timezone of host \"%s\" from archive\n\n",
		label.ll_hostname);
	else
	    printf("Note: timezone set to local timezone of host \"%s\"\n\n", host);
    }
    else if (tz != (char *)0) {
	if ((tzh = pmNewZone(tz)) < 0) {
	    fprintf(stderr, "%s: Cannot set timezone to \"%s\": %s\n",
		pmGetProgname(), tz, pmErrStr(tzh));
	    exit(1);
	}
	printf("Note: timezone set to \"TZ=%s\"\n\n", tz);
    }
    else
	tzh = pmNewContextZone();

    /* non-flag args are argv[optind] ... argv[argc-1] */
    while (optind < argc) {
	printf("%s:\n", argv[optind]);
	sts = dometric(argv[optind]);
	if (sts < 0)
	    printf("Error: %s\n", pmErrStr(sts));
	optind++;
    }

    exit(0);
}
