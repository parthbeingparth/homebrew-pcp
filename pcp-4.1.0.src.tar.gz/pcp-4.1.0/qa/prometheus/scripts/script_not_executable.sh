#! /bin/sh

echo '# HELP script_notexecutable Simple gauge metric with one instance'
echo '# Type script_notexecutable gauge'
echo 'script_notexecutable{abc="0"} 456'
exit 0
