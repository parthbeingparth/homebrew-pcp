#include "platform_defs.h"
extern uint16_t	crc16(const char *, int);
